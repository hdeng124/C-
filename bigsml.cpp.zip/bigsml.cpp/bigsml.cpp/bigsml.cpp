// I, Hanjie Deng, certify this is my own work and I have not collaborated with anyone

#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h> 
#define ARRAYSIZE 100

void GetValues(int x[], int *pN);
int FindBig(int x[], int n);
int FindSml(int x[], int n);
float FindAvg(int x[], int n);

void main()
{
	int a[100], myBig, mySml, n;
	float myAvg;
	GetValues(a, &n);
	myBig = FindBig(a, n);
	mySml = FindSml(a, n);
	myAvg = FindAvg(a, n);
	printf("The largest value is : %d\n", myBig);
	printf("The smallest value is : %d\n", mySml);
	printf("The average value is : %.2f\n", myAvg);
}

void GetValues(int x[], int *pN)
{
	int i;
	printf("Enter numbers of integer values: ");
	scanf("%d", pN);
	for (i = 0; i < *pN; i++)
	{
		printf("Enter value %d :", i + 1);
		scanf("%d", &x[i]);
	}

}

int FindBig(int x[], int n)
{
	int big, i;
	big = x[0];
	for (i = 1; i < n; i++)
		if (x[i]>big)
			big = x[i];
	return big;
}


int FindSml(int x[], int n)
{
	int small, i;
	small = x[0];
	for (i = 1; i < n; i++)
		if (x[i] < small)
			small = x[i];
	return small;
}

float FindAvg(int x[], int n)
{
	float avg;
	int sum, i;
	sum = 0;
	for (i = 0; i < n; i++)

		sum = sum + x[i];
	avg = sum / ((float)n);

	return avg;
}