﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IncomeTax
{
    class Program
    {
        static void Main(string[] args)
        {
            string [] validStates = {"CT", "ME", "MA", "NH", "RI", "VT"};
            string state;
            double taxrate;
            double monday1;
            double tuesday1;
            double wednesday1;
            double thursday1;
            double friday1;
            double monday2;
            double tuesday2;
            double wednesday2;
            double thursday2;
            double friday2;
            double overtime1;
            double overtime2;
            double overtime;
            double timeWorked1;
            double timeWorked2;
            double overtimeGross;
            double gross;
            double taxes;
            double pay;
            double totalGross;
            bool paidBiweekly;
            double hourlyWage;
            while(GetYesNo("Would you like to calculate your Taxes?:"))
            {
                state = GetState("What New England state do you work in?:");
                paidBiweekly = GetYesNo("Are you paid biweekly? ");
                hourlyWage = GetDouble("What is your hourly Wage? ", "Error - Enter a valid wage");
                // prompt and get hours for week 1
                // use GetDouble to get hours in.  You can store in 5 separate variables
                // or an array.
                // store running sum in totalHours
                // get hours for week 2 - add to hours from week 1
                // store in some var like totalHours
                Console.WriteLine("Week 1: \nHow many hours did you work the following days?");
                monday1 = GetDouble("Monday:","Error - Enter a valid number of hours");
                tuesday1 = GetDouble("Tuesday:","Error - Enter a valid number of hours");
                wednesday1 = GetDouble("Wednesday:","Error - Enter a valid number of hours");
                thursday1 = GetDouble("Thursday:","Error - Enter a valid number of hours");
                friday1 = GetDouble("Friday:","Error - Enter a valid number of hours");
                timeWorked1 = monday1 + tuesday1 + wednesday1 + thursday1 + friday1;
                // figure overtime for a one week period
                // figure total earnings for one week period
                overtime = 0;
                if (timeWorked1 > 35)
                {
                    overtime1 = timeWorked1 - 35;
                    overtimeGross = overtime1 * hourlyWage * 1.5;
                    gross = 35 * hourlyWage;
                    totalGross = gross + overtimeGross;
                    overtime = overtime1;
                }
                else
                {
                    gross = timeWorked1 * hourlyWage;
                    totalGross = gross;
                }
                if (paidBiweekly)
                {
                    // figure overtime for a two week period
                    // figure total earnings for two week period
                    Console.WriteLine("Week 2: \nHow many hours did you work the following days?");
                    monday2 = GetDouble("Monday:","Error - Enter a valid number of hours");
                    tuesday2 = GetDouble("Tuesday:","Error - Enter a valid number of hours");
                    wednesday2 = GetDouble("Wednesday:","Error - Enter a valid number of hours");
                    thursday2 = GetDouble("Thursday:","Error - Enter a valid number of hours");
                    friday2 = GetDouble("Friday:","Error - Enter a valid number of hours");
                    timeWorked2 = monday2 + tuesday2 + wednesday2 + thursday2 + friday2;
                    if (timeWorked2 > 35)
                    {
                        overtime2 = timeWorked2 - 35;
                        overtimeGross = overtime2 * hourlyWage * 1.5;
                        gross = 35 * hourlyWage;
                        totalGross = gross + overtimeGross;
                        overtime = overtime + overtime2;
                    }
                    else
                    {
                        gross = timeWorked2 * hourlyWage;
                        totalGross = totalGross + gross;
                    }
                }
                

                // figure taxes
                if (paidBiweekly)
                {
                    // check less than 1000  taxrate = 0.10
                    // check 1000 or greater and less than 4000 taxrate= 0.15
                    // check 4000 or greater and less than 10000 taxrate = 0.20
                    // check 10000 or greater and less than 20000 taxrate = 0.25
                    // else taxrate = 0.30
                    if (totalGross<1000)
                            taxrate = 0.10;
                    else if (totalGross<4000)
                            taxrate = 0.15;
                    else if (totalGross<10000)
                            taxrate = 0.20;
                    else if (totalGross<20000)
                            taxrate = 0.25;
                    else 
                            taxrate = 0.30;
                }
                else
                {
                    // check less than 500  taxrate = 0.10\
                    // check 500 or greater and less than 2000  taxrate = 0.15
                    // check 2000 or greater and less than 5000  taxrate = 0.20
                    // etc
                    if (totalGross<500)
                            taxrate = 0.10;
                    else if (totalGross<2000)
                            taxrate = 0.15;
                    else if (totalGross<5000)
                            taxrate = 0.20;
                    else if (totalGross<10000)
                            taxrate = 0.25;
                    else 
                            taxrate = 0.30;
                }
                switch (state)
                {
                    case "MA": 
                        taxrate = taxrate * 1.25;
                        break;
                    case "RI":
                        taxrate = taxrate * 1.07;
                        break;
                    case "CT": 
                        taxrate = taxrate * 1.10;
                        break;
                    case "ME": 
                        taxrate = taxrate * 0.80;
                        break;
                    case "NH": 
                        taxrate = taxrate * 0.85;
                        break;
                    case "VT": 
                        taxrate = taxrate * 0.92;
                        break;
                }
                taxes = taxrate * totalGross;
                pay = totalGross - taxes;
                Console.WriteLine("You worked {0} hour(s) of overtime.\nYou earned {1:C}. \nThe amount of taxes being taken out are {2:C}.", overtime,pay,taxes);
                //Console.WriteLine("You worked {0:C} hour(s) of overtime.", overtime);
                //Console.Writeline("You earned {0:C}.", pay);
                //Console.Writeline("The amount of taxes being taken out are {0:C}.", taxes);
            }
        }
        //functions////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //Universal get string with prompt, valid values, and error message.
        static string GetString(string prompt, string[] valid, string error)
        {
            string response;
            bool OK = false;
            do
            {
                Console.Write(prompt);
                response = Console.ReadLine().ToUpper();
                foreach (string s in valid) if (response == s) OK = true;
                if (!OK) Console.WriteLine(error);
            }while (!OK);
            return response;
        }
        //#1 & #3 (GET YES/NO OR Y/N RESPONSE. RETURN TRUE FOR YES/Y, FALSE FOR NO/N)
        static bool GetYesNo(string prompt)
        {
            string[] valid = {"YES","NO","Y","N"};
            string ans;
            ans = GetString(prompt, valid, "?Invalid response, please reenter");
            return (ans == "YES" || ans == "Y");
        }
        //#2 (State name?)
        static string GetState(string prompt)
        {
            string[] valid = { "CONNECTICUT", "CT", "MAINE", "ME", "MASSACHUSETTS", "MA", "NEW HAMPSHIRE", "NH", "RHODE ISLAND", "RI", "VERMONT", "VT" };
            string ans;
            ans = GetString(prompt, valid, "?Invalid response, please reenter");
            if (ans == "CONNECTICUT") ans = "CT";
            if (ans == "MAINE") ans = "ME";
            if (ans == "MASSACHUSETTS") ans = "MA";
            if (ans == "NEW HAMPSHIRE") ans = "NH";
            if (ans == "RHODE ISLAND") ans = "RI";
            if (ans == "VERMONT") ans = "VT";
            return ans;
        }
         // UNIVERSAL GET A DOUBLE WITH PROMPT
        static double GetDouble(string prompt, string error)
        {
            double result;
            string userInput;
            bool OK = false; //assume bad data
            do
            {
                Console.Write(prompt);
                userInput = Console.ReadLine();
                OK = double.TryParse(userInput,out result);
                if(!OK)Console.WriteLine(error);
            }while(!OK);
            return result;
        }
    }
}
