﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Problem_2__Colors_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Additive_CheckedChanged(object sender, EventArgs e)
        {
            if (Additive.Checked == true)
            {
                ColorBox.Text = Additive.Text;
                cB1.Text = "Red";
                cB1.Checked = false;
                cB2.Text = "Green";
                cB2.Checked = false;
                cB3.Text = "Blue";
                cB3.Checked = false;
                DisplayBox.BackColor = Color.Black;
            }
        }

        private void Subtractive_CheckedChanged(object sender, EventArgs e)
        {
            if (Subtractive.Checked == true)
            {
                ColorBox.Text = Subtractive.Text;
                cB1.Text = "Cyan";
                cB1.Checked = false;
                cB2.Text = "Yellow";
                cB2.Checked = false;
                cB3.Text = "Magenta";
                cB3.Checked = false;
                DisplayBox.BackColor = Color.White;
            }
        }

        private void cB1_CheckedChanged(object sender, EventArgs e)
        {
            if (Additive.Checked == true)//additive on
            {//Code for Red switch
                if (cB1.Checked == true)//red on
                {
                    if (cB2.Checked == true)//green on
                    {
                        if (cB3.Checked == true)//blue on
                        {
                            DisplayBox.BackColor = Color.White;
                        }
                        else//blue off
                        {
                            DisplayBox.BackColor = Color.Yellow;
                        }
                    }
                    else//green off
                    {
                        if (cB3.Checked == true)//blue on
                        {
                            DisplayBox.BackColor = Color.Magenta;
                        }
                        else//blue off
                        {
                            DisplayBox.BackColor = Color.Red;
                        }
                    }
                }
                else//red off
                {
                    if (cB2.Checked == true)//green on
                    {
                        if (cB3.Checked == true)//blue on
                        {
                            DisplayBox.BackColor = Color.Cyan;
                        }
                        else//blue off
                        {
                            DisplayBox.BackColor = Color.Green;
                        }
                    }
                    else//green off
                    {
                        if (cB3.Checked == true)//blue on
                        {
                            DisplayBox.BackColor = Color.Blue;
                        }
                        else//blue off
                        {
                            DisplayBox.BackColor = Color.Black;
                        }
                    }
                }
            }
            if (Subtractive.Checked == true)//Subtractive on
            {//Code for Cyan switch
                if (cB1.Checked == true)//Cyan on
                {
                    if (cB2.Checked == true)//Yellow on
                    {
                        if (cB3.Checked == true)//Magenta on
                        {
                            DisplayBox.BackColor = Color.Black;
                        }
                        else//Magenta off
                        {
                            DisplayBox.BackColor = Color.Green;
                        }
                    }
                    else//Yellow off
                    {
                        if (cB3.Checked == true)//Magenta on
                        {
                            DisplayBox.BackColor = Color.Blue;
                        }
                        else//Magenta off
                        {
                            DisplayBox.BackColor = Color.Cyan;
                        }
                    }
                }
                else//Cyan off
                {
                    if (cB2.Checked == true)//Yellow on
                    {
                        if (cB3.Checked == true)//Magenta on
                        {
                            DisplayBox.BackColor = Color.Red;
                        }
                        else//Magenta off
                        {
                            DisplayBox.BackColor = Color.Yellow;
                        }
                    }
                    else//Yellow off
                    {
                        if (cB3.Checked == true)//Magenta on
                        {
                            DisplayBox.BackColor = Color.Magenta;
                        }
                        else//blue off
                        {
                            DisplayBox.BackColor = Color.White;
                        }
                    }
                }
            }
        }

        private void cB2_CheckedChanged(object sender, EventArgs e)
        {
            if (Additive.Checked == true)//additive on
            {//Code for Green switch
                if (cB2.Checked == true)//green on
                {
                    if (cB1.Checked == true)//red on
                    {
                        if (cB3.Checked == true)//blue on
                        {
                            DisplayBox.BackColor = Color.White;
                        }
                        else//blue off
                        {
                            DisplayBox.BackColor = Color.Yellow;
                        }
                    }
                    else//red off
                    {
                        if (cB3.Checked == true)//blue on
                        {
                            DisplayBox.BackColor = Color.Cyan;
                        }
                        else//blue off
                        {
                            DisplayBox.BackColor = Color.Green;
                        }
                    }
                }
                else//green off
                {
                    if (cB1.Checked == true)//red on
                    {
                        if (cB3.Checked == true)//blue on
                        {
                            DisplayBox.BackColor = Color.Magenta;
                        }
                        else//blue off
                        {
                            DisplayBox.BackColor = Color.Red;
                        }
                    }
                    else//red off
                    {
                        if (cB3.Checked == true)//blue on
                        {
                            DisplayBox.BackColor = Color.Blue;
                        }
                        else//blue off
                        {
                            DisplayBox.BackColor = Color.Black;
                        }
                    }
                }
            }
            if (Subtractive.Checked == true)//Subtractive on
            {//Code for Yellow switch
                if (cB2.Checked == true)//Yellow on
                {
                    if (cB1.Checked == true)//Cyan on
                    {
                        if (cB3.Checked == true)//Magenta on
                        {
                            DisplayBox.BackColor = Color.Black;
                        }
                        else//Magenta off
                        {
                            DisplayBox.BackColor = Color.Green;
                        }
                    }
                    else//Cyan off
                    {
                        if (cB3.Checked == true)//Magenta on
                        {
                            DisplayBox.BackColor = Color.Red;
                        }
                        else//Magenta off
                        {
                            DisplayBox.BackColor = Color.Yellow;
                        }
                    }
                }
                else//Yellow off
                {
                    if (cB1.Checked == true)//Cyan on
                    {
                        if (cB3.Checked == true)//Magenta on
                        {
                            DisplayBox.BackColor = Color.Blue;
                        }
                        else//Magenta off
                        {
                            DisplayBox.BackColor = Color.Cyan;
                        }
                    }
                    else//Cyan off
                    {
                        if (cB3.Checked == true)//Magenta on
                        {
                            DisplayBox.BackColor = Color.Magenta;
                        }
                        else//Magenta off
                        {
                            DisplayBox.BackColor = Color.White;
                        }
                    }
                }
            }
        }

        private void cB3_CheckedChanged(object sender, EventArgs e)
            
        {
            if (Additive.Checked == true)//additive on
            {//Code for Blue switch
                if (cB3.Checked == true)//blue on
                {
                    if (cB2.Checked == true)//green on
                    {
                        if (cB1.Checked == true)//Red on
                        {
                            DisplayBox.BackColor = Color.White;
                        }
                        else//Red off
                        {
                            DisplayBox.BackColor = Color.Cyan;
                        }
                    }
                    else//green off
                    {
                        if (cB1.Checked == true)//Red on
                        {
                            DisplayBox.BackColor = Color.Magenta;
                        }
                        else//Red off
                        {
                            DisplayBox.BackColor = Color.Blue;
                        }
                    }
                }
                else//blue off
                {
                    if (cB2.Checked == true)//green on
                    {
                        if (cB1.Checked == true)//Red on
                        {
                            DisplayBox.BackColor = Color.Yellow;
                        }
                        else//Red off
                        {
                            DisplayBox.BackColor = Color.Green;
                        }
                    }
                    else//green off
                    {
                        if (cB1.Checked == true)//Red on
                        {
                            DisplayBox.BackColor = Color.Red;
                        }
                        else//Red off
                        {
                            DisplayBox.BackColor = Color.Black;
                        }
                    }
                }
            }
            if (Subtractive.Checked == true)//Subtractive on
            {//Code for Magenta switch
                if (cB3.Checked == true)//Magenta on
                {
                    if (cB2.Checked == true)//Yellow on
                    {
                        if (cB1.Checked == true)//Cyan on
                        {
                            DisplayBox.BackColor = Color.Black;
                        }
                        else//Cyan off
                        {
                            DisplayBox.BackColor = Color.Red;
                        }
                    }
                    else//Yellow off
                    {
                        if (cB1.Checked == true)//Cyan on
                        {
                            DisplayBox.BackColor = Color.Blue;
                        }
                        else//Red off
                        {
                            DisplayBox.BackColor = Color.Magenta;
                        }
                    }
                }
                else//Magenta off
                {
                    if (cB2.Checked == true)//Yellow on
                    {
                        if (cB1.Checked == true)//Cyan on
                        {
                            DisplayBox.BackColor = Color.Green;
                        }
                        else//Cyan off
                        {
                            DisplayBox.BackColor = Color.Yellow;
                        }
                    }
                    else//Yellow off
                    {
                        if (cB1.Checked == true)//Cyan on
                        {
                            DisplayBox.BackColor = Color.Cyan;
                        }
                        else//Cyan off
                        {
                            DisplayBox.BackColor = Color.White;
                        }
                    }
                }
            }
        }
    }
}
