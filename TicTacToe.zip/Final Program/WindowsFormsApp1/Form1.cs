﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private UdpClient conn = new UdpClient();
        public UdpClient Conn { get => conn; set => conn = value; }
        private string StringOut = "192.168.11.11";
        public int numBytesIn;
        public Byte[] inBytes = new Byte[128];
        public Byte[] outBytes = new Byte[128];
        public string inData;
        public string outData;
        public string[] RemoteHost;
        public char[] Colon = { ':' };
        public Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        public EndPoint temp_remoteIP = (EndPoint)new IPEndPoint(IPAddress.Any, 0);
        public IPEndPoint remoteIP = new IPEndPoint(IPAddress.Any, 0);
        public IPEndPoint localIP;
        public IPAddress remote_IP;
        public int CharIndex, remotePort;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            s.Connect("8.8.8.8", 60001);        //connection to google's DNS server (I think) just to get
            localIP = (IPEndPoint)s.LocalEndPoint;  //the local IP
            s.Close();      //nuke the socket
            s = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp); //and make a new one
            s.Bind(localIP);    //bind socket to local IP to allow Receive operation
            SocketAsyncEventArgs temp = new SocketAsyncEventArgs();     
            temp.SetBuffer(inBytes, 0, 128);                                // inBytes is input buffer
            temp.RemoteEndPoint = new IPEndPoint(IPAddress.Any, 0) as EndPoint;     // any IP, any port to establish connection
            temp.Completed += NewBytes;                     // NewBytes() is the event handler for the async receive
            if (s.ReceiveFromAsync(temp) == false)      // if ReceiveFromAsync returns false, there was data available 
            {                                           // and it acted as a syncronous Receive
                inData = Encoding.ASCII.GetString(inBytes);
                RemoteHost = inData.Split(Colon, 2);                    // because the connecting request message is just 
                if (IPAddress.TryParse(RemoteHost[0], out remote_IP))   // the sender's IP, the contents of the first message received 
                {                                                       // becomes the remote host address through some string parsing
                    if (Int32.TryParse(RemoteHost[1], out remotePort))
                    {
                        textBox1.Text = "Connecting...";   // outputting errors and status messages to the IP address textbox for now
                        remoteIP = new IPEndPoint(remote_IP, remotePort);
                        temp_remoteIP = (EndPoint)remoteIP;
                        s.Connect(temp_remoteIP);
                    }
                    else
                    {
                        textBox1.Text = "Connection Failed! bad port";
                    }
                }
                else
                {
                    textBox1.Text = "Connection Failed! bad IP";
                }
                
            }   

            remoteIP = (IPEndPoint)temp_remoteIP;
        }

        static void NewBytes(object sender, SocketAsyncEventArgs e)
        {

        }

        private void Form1_Paint(object sender, PaintEventArgs e)   //draws the board and Xs and Os
        {
            Pen p = new Pen(Color.Black, 3);
            e.Graphics.DrawLine(p, 15, ((this.Height - 70) / 3) + 15, this.Width-30, ((this.Height - 70) / 3) + 15);
            e.Graphics.DrawLine(p, 15, (2*(this.Height - 70) / 3) + 15, this.Width-30, (2*(this.Height - 70) / 3) + 15);
            e.Graphics.DrawLine(p, ((this.Width-45)/3)+15, 15, ((this.Width - 45) / 3) + 15, this.Height-55);
            e.Graphics.DrawLine(p, (2*(this.Width - 45) / 3) + 15, 15, (2*(this.Width - 45) / 3) + 15, this.Height-55);

            //top left x
            e.Graphics.DrawLine(p, 25, 25, ((this.Width - 45) / 3) + 5, ((this.Height - 70) / 3) + 5);
            e.Graphics.DrawLine(p, ((this.Width - 45) / 3) + 5, 25, 25, ((this.Height - 70) / 3) + 5);
            
            //top mid x
            e.Graphics.DrawLine(p, ((this.Width - 45) / 3) + 25, 25, (2*(this.Width - 45) / 3) + 5, ((this.Height - 70) / 3) + 5);
            e.Graphics.DrawLine(p, (2*(this.Width - 45) / 3) + 5, 25, ((this.Width - 45) / 3) + 25, ((this.Height - 70) / 3) + 5);
            
            ////top right x
            //e.Graphics.DrawLine(p, (2*(this.Width-45)/3)+25 , 25 , this.Width-40 , ((this.Height-70)/3)+5);
            //e.Graphics.DrawLine(p, this.Width-40 , 25 , (2*(this.Width-45)/3)+25 , ((this.Height-70)/3)+5);
            //
            ////mid left x
            //e.Graphics.DrawLine(p, 25, ((this.Height - 70) / 3) + 25, ((this.Width - 45) / 3) + 5, (2*(this.Height - 70) / 3) + 5);
            //e.Graphics.DrawLine(p, ((this.Width - 45) / 3) + 5, ((this.Height - 70) / 3) + 25, 25, (2*(this.Height - 70) / 3) + 5);
            //
            //mid mid x
            e.Graphics.DrawLine(p, ((this.Width - 45) / 3) + 25, ((this.Height - 70) / 3) + 25, (2 * (this.Width - 45) / 3) + 5, (2*(this.Height - 70) / 3) + 5);
            e.Graphics.DrawLine(p, (2 * (this.Width - 45) / 3) + 5, ((this.Height - 70) / 3) + 25, ((this.Width - 45) / 3) + 25, (2*(this.Height - 70) / 3) + 5);
            
            //mid right x
            e.Graphics.DrawLine(p, (2 * (this.Width - 45) / 3) + 25, ((this.Height - 70) / 3) + 25, this.Width - 40, (2*(this.Height - 70) / 3) + 5);
            e.Graphics.DrawLine(p, this.Width - 40, ((this.Height - 70) / 3) + 25, (2 * (this.Width - 45) / 3) + 25, (2*(this.Height - 70) / 3) + 5);
            
            //bottom left x
            e.Graphics.DrawLine(p, 25, (2*(this.Height - 70) / 3) + 25, ((this.Width - 45) / 3) + 5, this.Height - 65);
            e.Graphics.DrawLine(p, ((this.Width - 45) / 3) + 5, (2*(this.Height - 70) / 3) + 25, 25, this.Height - 65);
            
            ////bottom mid x
            //e.Graphics.DrawLine(p, ((this.Width - 45) / 3) + 25, (2*(this.Height - 70) / 3) + 25, (2 * (this.Width - 45) / 3) + 5, this.Height - 65);
            //e.Graphics.DrawLine(p, (2 * (this.Width - 45) / 3) + 5, (2*(this.Height - 70) / 3) + 25, ((this.Width - 45) / 3) + 25, this.Height - 65);
            //
            ////bottom right x
            //e.Graphics.DrawLine(p, (2 * (this.Width - 45) / 3) + 25, (2*(this.Height - 70) / 3) + 25, this.Width - 40, this.Height-65);
            //e.Graphics.DrawLine(p, this.Width - 40, (2*(this.Height - 70) / 3) + 25, (2 * (this.Width - 45) / 3) + 25, this.Height-65);

            ////top left o
            //e.Graphics.DrawEllipse(p, 25, 25, ((this.Width - 45) / 3) - 20, ((this.Height - 70) / 3) - 20);
            //
            ////top mid o
            //e.Graphics.DrawEllipse(p, ((this.Width - 45) / 3) + 25, 25, ((2*(this.Width - 45) / 3) + 5) - (((this.Width - 45) / 3) + 25), ((this.Height - 70) / 3) - 20);
            //
            //top right o
            e.Graphics.DrawEllipse(p, (2*(this.Width - 45) / 3) + 25, 25, (this.Width-40) - ((2 * (this.Width - 45) / 3) + 25), ((this.Height - 70) / 3) - 20);
            
            //mid left o
            e.Graphics.DrawEllipse(p, 25, ((this.Height - 70) / 3) + 25, ((this.Width - 45) / 3) - 20, ((2 * (this.Height - 70) / 3) + 5) - (((this.Height - 70) / 3) + 25));
            
            ////mid mid o
            //e.Graphics.DrawEllipse(p, ((this.Width - 45) / 3) + 25, ((this.Height - 70) / 3) + 25, ((2 * (this.Width - 45) / 3) + 5) - (((this.Width - 45) / 3) + 25), ((2*(this.Height - 70) / 3) + 5) - (((this.Height - 70) / 3) + 25));
            //
            ////mid right o
            //e.Graphics.DrawEllipse(p, (2 * (this.Width - 45) / 3) + 25, ((this.Height - 70) / 3) + 25, (this.Width - 40) - ((2 * (this.Width - 45) / 3) + 25), ((2 * (this.Height - 70) / 3) + 5) - (((this.Height - 70) / 3) + 25));
            //
            ////bottom left o
            //e.Graphics.DrawEllipse(p, 25, (2*(this.Height - 70) / 3) + 25, ((this.Width - 45) / 3) - 20, (this.Height - 65) - ((2 * (this.Height - 70) / 3) + 25));
            //
            //bottom mid o
            e.Graphics.DrawEllipse(p, ((this.Width - 45) / 3) + 25, (2*(this.Height - 70) / 3) + 25, ((2 * (this.Width - 45) / 3) + 5) - (((this.Width - 45) / 3) + 25), (this.Height - 65) - ((2 * (this.Height - 70) / 3) + 25));
            
            //bottom right o
            e.Graphics.DrawEllipse(p, (2 * (this.Width - 45) / 3) + 25, (2*(this.Height - 70) / 3) + 25, (this.Width - 40) - ((2 * (this.Width - 45) / 3) + 25), (this.Height - 65) - ((2 * (this.Height - 70) / 3) + 25));
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            this.Invalidate();
        }

        private void button1_Click(object sender, EventArgs e)      //for the connect button
        {
            s.Connect(textBox1.Text, Convert.ToInt32(textBox2.Text));
            localIP = (IPEndPoint)s.LocalEndPoint;
            s.Send(Encoding.ASCII.GetBytes(localIP.Address.ToString() + ":" + textBox2.Text));  
                //I think I'm gonna get rid of the port select and just pick one and stick with it

        }
    }
}
