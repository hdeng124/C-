﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Problem_1__Calculator_
{
    public partial class Form1 : Form
    {
        double Ans;
        double V1, V2;
        double result;
        bool OK1 = true;
        bool OK2 = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Add_Click(object sender, EventArgs e)
        {
            OK1 = double.TryParse(Value1.Text, out result);
            if (!OK1)
            {
                MessageBox.Show("Could not solve problem.  Please use valid values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Value1.Text = null;
                Value2.Text = null;
            }
            else
            {
                OK2 = double.TryParse(Value2.Text, out result);
                if (!OK2)
                {
                    MessageBox.Show("Could not solve problem.  Please use valid values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Value1.Text = null;
                    Value2.Text = null;
                }
                else
                {
                    V1 = double.Parse(Value1.Text, System.Globalization.CultureInfo.InvariantCulture);
                    V2 = double.Parse(Value2.Text, System.Globalization.CultureInfo.InvariantCulture);
                    Ans = V1 + V2;
                    Answer.Text = Convert.ToString(Ans);
                }
            }
        }

        private void Subtract_Click(object sender, EventArgs e)
        {
            OK1 = double.TryParse(Value1.Text, out result);
            if (!OK1)
            {
                MessageBox.Show("Could not solve problem.  Please use valid values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Value1.Text = null;
                Value2.Text = null;
            }
            else
            {
                OK2 = double.TryParse(Value2.Text, out result);
                if (!OK2)
                {
                    MessageBox.Show("Could not solve problem.  Please use valid values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Value1.Text = null;
                    Value2.Text = null;
                }
                else
                {
                    V1 = double.Parse(Value1.Text, System.Globalization.CultureInfo.InvariantCulture);
                    V2 = double.Parse(Value2.Text, System.Globalization.CultureInfo.InvariantCulture);
                    Ans = V1 - V2;
                    Answer.Text = Convert.ToString(Ans);
                }
            }
        }
        private void Multiply_Click(object sender, EventArgs e)
        {
            OK1 = double.TryParse(Value1.Text, out result);
            if (!OK1)
            {
                MessageBox.Show("Could not solve problem.  Please use valid values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Value1.Text = null;
                Value2.Text = null;
            }
            else
            {
                OK2 = double.TryParse(Value2.Text, out result);
                if (!OK2)
                {
                    MessageBox.Show("Could not solve problem.  Please use valid values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Value1.Text = null;
                    Value2.Text = null;
                }
                else
                {
                    V1 = double.Parse(Value1.Text, System.Globalization.CultureInfo.InvariantCulture);
                    V2 = double.Parse(Value2.Text, System.Globalization.CultureInfo.InvariantCulture);
                    Ans = V1 * V2;
                    Answer.Text = Convert.ToString(Ans);
                }
            }
        }

        private void Divide_Click(object sender, EventArgs e)
        {
            OK1 = double.TryParse(Value1.Text, out result);
            if (!OK1)
            {
                MessageBox.Show("Could not solve problem.  Please use valid values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Value1.Text = null;
                Value2.Text = null;
            }
            else
            {
                OK2 = double.TryParse(Value2.Text, out result);
                if (!OK2)
                {
                    MessageBox.Show("Could not solve problem.  Please use valid values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Value1.Text = null;
                    Value2.Text = null;
                }
                else
                {
                    V1 = double.Parse(Value1.Text, System.Globalization.CultureInfo.InvariantCulture);
                    V2 = double.Parse(Value2.Text, System.Globalization.CultureInfo.InvariantCulture);
                    Ans = V1 / V2;
                    Answer.Text = Convert.ToString(Ans);
                }
            }
        }
        private void Value1_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
