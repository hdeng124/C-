﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adventure
{
    class Puzzle
    {
        public string Name;
        public Key KeyNeeded;
        public Puzzle(string n, Key k)
        {
            Name = n;
            KeyNeeded = k;
        }
        public Puzzle()
        {
            Name = "";
            KeyNeeded = null;
        }
    }
}
