﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Market_Place
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Store> stores = new List<Store>();
            ReadStores(out stores);
            ////////////////////////////////////////
            // Now write out inventory for each store
            // (Not needed for final program)
            //Console.WriteLine("** STORE AND INVENTORY LIST **");
      /*      foreach (Store store in stores)
            {
                Console.WriteLine(store.Name);
                for (int i = 0; i < store.NumItems; i++)
                    Console.WriteLine("    {0,-10} {1,5} {2,7:$0.00}", store.GetItem(i).Name, store.GetItem(i).Quan, store.GetItem(i).PriceEach);
            }
            for (int x = 0; x < stores.Count; x++)
            {
                Console.WriteLine(stores[x].Name);
                for (int y = 0; y < stores[x].NumItems; y++)
                {
                    Items tmpItem = stores[x].GetItem(y);
                    Console.WriteLine("{0} {1} {2}", tmpItem.Name, tmpItem.Quan, tmpItem.PriceEach);
                }
            }
        */    ////////////////////////////////////////
            string shop;
            string[] storeList;
            double wallet;
            wallet = 100.00;
            while (GetYesNo("Welcome to the ECE264 mall.  Would you like to shop?:"))
            {
                Console.WriteLine("Which store would you like to go too?");
                foreach (Store store in stores)
                {
                    Console.WriteLine("     {0}", store.Name);
                }
                //readline();

                /*Store stre = new Store();
                if (shop == "C")
                    stre = stores[1];
                else if (shop == "B")
                    stre = stores[0];
                else
                    Console.WriteLine("invalid store");
                */    
                //item.GetItem(int i);
                Console.WriteLine("What would you like to buy?");
                foreach (var item in stores);//var item or store item?

        /*
                foreach (Store store in stores)
                {
                    //Console.WriteLine(store.Name);
                    for (int i = 0; i < store.NumItems; i++)
                        Console.WriteLine("    {0,-10} {1,5} {2,7:$0.00}", store.GetItem(i).Name, store.GetItem(i).Quan, store.GetItem(i).PriceEach);
                }
    */
                //{

                    //for (int i = 0; i < item.NumItems; i++)
                        //Console.WriteLine("    {0,-10} {2,7:$0.00}", item.GetItem(i).Name, item.GetItem(i).PriceEach);
               // }
                


                //foreach (Items item in stores)
                //{
                    //Console.WriteLine("     {0}", item.Name);
                //}

                //Console.WriteLine("{0}\n{1:C}\n{2:C}", overtime, pay, taxes);
                /*
                double stotal;
                double total;
                stotal = 0;
                total = 0;
                for (int x = 0; x < stores.Count; x++)
                {
                    for (int y = 0; y < stores[x].NumItems; y++)
                    {
                        Item tmpItem = stores[x].GetItem(y);
                        //Console.WriteLine("{0} {1}", tmpItem.Quan, tmpItem.PriceEach);
                        stotal = stotal + (tmpItem.Quan * tmpItem.PriceEach);
                        total = total + (tmpItem.Quan * tmpItem.PriceEach);
                    }
                    Console.WriteLine("    {0,-10} {1,5}", stores[x].Name, stotal);
                    stotal = 0;
                }
                Console.WriteLine("              --------");
                Console.WriteLine("    {0,17}", total);
                 * */
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        //Function writen by Prof.P.H. Vial
        static void ReadStores(out List<Store> s)
        {
            string line;
            string[] tokens;
            string storename;
            int storequan;
            s = new List<Store>(); //  s = null; doesn't work;
            try
            {
                using (StreamReader sr = new StreamReader(@"..\..\inventory.txt"))
                {
                    while (sr.Peek() >= 0)
                    {
                        List<Items> myItemList = new List<Items>();
                        line = sr.ReadLine();
                        tokens = line.Split(' ');
                        storename = tokens[0];
                        storequan = Convert.ToInt32(tokens[1]);
                        for (int i = 0; i < storequan; i++)
                        {
                            line = sr.ReadLine();
                            tokens = line.Split(' ');
                            Items myItem = new Items(tokens[0], Convert.ToInt32(tokens[1]), Convert.ToDouble(tokens[2]));
                            myItemList.Add(myItem);
                        }
                        s.Add(new Store(storename, storequan, myItemList));
                    }
                    sr.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Can't open file because: {0}", e.Message);
            }
        }
        //Generic yes no function
        static bool GetYesNo(string prompt)
        {
            string[] valid = { "YES", "NO", "Y", "N" };
            string ans;
            ans = GetString(prompt, valid, "?Invalid response, please reenter");
            return (ans == "YES" || ans == "Y");
        }
        //Universal get string with prompt, valid values, and error message.
        static string GetString(string prompt, string[] valid, string error)
        {
            string response;
            bool OK = false;
            do
            {
                Console.Write(prompt);
                response = Console.ReadLine().ToUpper();
                foreach (string s in valid) if (response == s) OK = true;
                if (!OK) Console.WriteLine(error);
            } while (!OK);
            return response;
        }
        // UNIVERSAL GET A DOUBLE WITH PROMPT
        static double GetDouble(string prompt, string error)
        {
            double result;
            string userInput;
            bool OK = false; //assume bad data
            do
            {
                Console.Write(prompt);
                userInput = Console.ReadLine();
                OK = double.TryParse(userInput, out result);
                if (!OK) Console.WriteLine(error);
            } while (!OK);
            return result;
        }
        static string GetStore(string prompt)
        {
            string[] valid = { "BOOKSRUS", "B", "CVS", "C" };
            string ans;
            ans = GetString(prompt, valid, "?Invalid response, please reenter");
            if (ans == "BOOKSRUS") ans = "B";
            if (ans == "CVS") ans = "C";
            return ans;
        }


    }
}
