﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adventure
{
    class Weapon
    {
        public string Name;
        public int Pwr;
        public Weapon(string n, int p)
        {
            Name = "";
            Pwr = 0;
        }
        public Weapon()
        {
            Name = "";
            Pwr = 0;
        }
    }
}
