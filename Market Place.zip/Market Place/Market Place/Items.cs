﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Market_Place
{
    class Items
    {
        private string name;
        private int quan;
        private double priceEach;

        public string Name { get { return name; } set { name = value; } }
        public int Quan { get { return quan; } set { quan = value; } }
        public double PriceEach { get { return priceEach; } set { priceEach = value; } }

        public Items() { Name = ""; Quan = 0; PriceEach = 0.0; }

        public Items(string n, int q, double p) { Name = n; Quan = q; PriceEach = p; }
    }
}
