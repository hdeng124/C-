﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pig
{
    class Program
    {
        static void Main(string[] args)
        {
        Beginning:
            int seed = GetInteger("Enter seed (-1 for random):", -1, int.MaxValue, "Please enter an integer", "Value must be between -1 and" + int.MaxValue); //promt user for seed value
            Random rgen = new Random();   //initialize rgen outside of loop
            if (seed == -1)
                rgen = new Random(DateTime.Now.Millisecond); //if seed is -1, generate a totally random value
            else
                rgen = new Random(seed);     //if seed is not -1, take user input as seed value

            int wscore = GetInteger("Enter winning score <25-100>:", 25, 100, "Please enter an integer", "Value must be between 25 and 100");   //promt user input for winning score
            
            int Croll = 0; int Hroll; int Ctotal = 0; int Htotal = 0;  //initializing integers
            CompT:
            Console.WriteLine("\n*** COMPUTER TURN***"); //print line
            Croll = rgen.Next(6) + 1;  // generate random # between 1 and 6
            /*while (Ctotal < wscore)
            {*/
            int ctotal = 0;  //small c for loop
            if (Croll != 1)    //if roll is not 1 then do loop
            {

                do
                {
                    if (Croll == 1)
                    {
                        ctotal = 0;
                        goto Outer; //get out of loop to Outer if Croll is 1
                    }
                    ctotal = Croll + ctotal;  //turn total 
                    Console.WriteLine("Roll: {0}, Turn Total: {1}", Croll, ctotal); //print roll and total
                    Croll = rgen.Next(6) + 1;  //re generate a random number btw 1 and 6
                    
                } while (ctotal < 20);
               
                Ctotal = ctotal + Ctotal;

                if (Ctotal > wscore)
                {
                    Console.WriteLine("\nCurrent Score:\nComputer: {0}\nHuman: {1}", Ctotal, Htotal);
                    Console.WriteLine("\nFinal Score:\nComputer: {0}\nHuman: {1}\nCOMPUTER WINS!", Ctotal, Htotal);
                    if (GetYesNo("Do you wish to play again? <Y or N>:"))
                        goto Beginning;
                    else
                        goto End;
                }
               
              }
            Outer:
                
            if (ctotal == 0)
            {
                Ctotal = ctotal + Ctotal;
                Console.WriteLine("Roll: {0}, Turn Total: {1}", Croll, ctotal);
            }
            

            Console.WriteLine("\nCurrent Score:\nComputer: {0}\nHuman: {1}", Ctotal, Htotal);



            Console.WriteLine("\n*** HUMANS TURN ***");

            
            if (GetRH("Enter command (h/r):"))    //if user input is r
            {
                int htotal = 0;// htotal for loop
                Hroll = rgen.Next(6) + 1;  // generate random # between 1 and 6
                if (Hroll != 1)  //do loop if Roll is not 1
                {


                    htotal = htotal + Hroll;  //turn total 
                    Console.WriteLine("Roll: {0}, Turn Total: {1}", Hroll, htotal); //print roll and total
                    if (GetRH("Enter command (h/r):"))
                    {
                        Hroll = rgen.Next(6) + 1;  // generate random # between 1 and 6
                        if (Hroll == 1)
                        {
                            htotal = 0;

                            Console.WriteLine("Roll: {0}, Turn Total: {1}", Hroll, htotal); //print roll and total
                            goto CompT;
                        }
                        htotal = htotal + Hroll;  //turn total 
                        Console.WriteLine("Roll: {0}, Turn Total: {1}", Hroll, htotal); //print roll and total
                        Htotal = htotal + Htotal;
                        do
                        {
                            if (GetRH("Enter command (h/r):"))
                            {
                                Hroll = rgen.Next(6) + 1;  //re generate a random number btw 1 and 6

                                if (Hroll == 1)
                                {
                                    htotal = 0;


                                }


                                if (htotal == 0)
                                {
                                    Htotal = htotal + Htotal;
                                    Console.WriteLine("Roll: {0}, Turn Total: {1}", Hroll, htotal);
                                    Console.WriteLine("\nCurrent Score:\nComputer: {0}\nHuman: {1}", Ctotal, Htotal);
                                    goto CompT;
                                }
                                htotal = htotal + Hroll;  //turn total 
                                Console.WriteLine("Roll: {0}, Turn Total: {1}", Hroll, htotal); //print roll and total
                                Htotal = htotal + Htotal;
                            }
                            else
                            {
                                Htotal = htotal + Htotal;
                                Console.WriteLine("\nCurrent Score:\nComputer: {0}\nHuman: {1}", Ctotal, Htotal);
                                if (Htotal >= wscore)
                                {
                                    Console.WriteLine("\nCurrent Score:\nComputer: {0}\nHuman: {1}", Ctotal, Htotal);
                                    Console.WriteLine("\nFinal Score:\nComputer: {0}\nHuman: {1}\nHUMAN WINS!", Ctotal, Htotal);
                                    if (GetYesNo("Do you wish to play again? <Y or N>:"))
                                        goto Beginning;
                                    else
                                        goto End;
                                }
                                goto CompT;
                            }
                        } while (htotal < wscore);
                        Htotal = htotal + Htotal;
                        if (htotal >= wscore)
                        {
                            Console.WriteLine("\nCurrent Score:\nComputer: {0}\nHuman: {1}", Ctotal, Htotal);
                            Console.WriteLine("\nFinal Score:\nComputer: {0}\nHuman: {1}\nHUMAN WINS!", Ctotal, Htotal);
                            if (GetYesNo("Do you wish to play again? <Y or N>:"))
                                goto Beginning;
                            else
                                goto End;
                        }
                    }

                    else
                    {
                        Htotal = htotal + Htotal;
                        Console.WriteLine("\nCurrent Score:\nComputer: {0}\nHuman: {1}", Ctotal, Htotal);
                        if (Htotal >= wscore)
                        {
                            Console.WriteLine("\nCurrent Score:\nComputer: {0}\nHuman: {1}", Ctotal, Htotal);
                            Console.WriteLine("\nFinal Score:\nComputer: {0}\nHuman: {1}\nHUMAN WINS!", Ctotal, Htotal);
                            if (GetYesNo("Do you wish to play again? <Y or N>:"))
                                goto Beginning;
                            else
                                goto End;
                        }
                        goto CompT;
                    }
                }
                else
                {
                    htotal = 0;//turn total 
                    Htotal = htotal + Htotal;
                    Console.WriteLine("Roll: {0}, Turn Total: {1}", Hroll, htotal); //print roll and total
                    Console.WriteLine("\nCurrent Score:\nComputer: {0}\nHuman: {1}", Ctotal, Htotal);
                    goto CompT;
                }
                



            }
            else
            {
                
                
                Console.WriteLine("\nCurrent Score:\nComputer: {0}\nHuman: {1}", Ctotal, Htotal);
                goto CompT;
            }
            
                


        End:
            Console.WriteLine("Bye Bye!");

        
    }
      


        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        static int GetInteger(string prompt, int lo, int hi, string erroprNotInt, string errorRange)
        {
            int result;
            string userInput;
            bool OKInt = false, OKRange = false;
            do
            {
                Console.Write(prompt);
                userInput = Console.ReadLine();
                OKInt = Int32.TryParse(userInput, out result);
                if (OKInt)
                {
                    OKRange = lo <= result && result <= hi;
                    if (!OKRange) Console.WriteLine(errorRange);
                }
                else
                    Console.WriteLine(erroprNotInt);
            } while (!OKInt || !OKRange);
            return result;
        }
        static string GetString(string prompt, string[] valid, string error)
        {
            string response;
            bool OK = false;
            do
            {
                Console.Write(prompt);
                response = Console.ReadLine().ToUpper();
                foreach (string s in valid) if (response == s.ToUpper()) OK = true;
                if (!OK) Console.WriteLine(error);
            } while (!OK);
            return response;
        }
        static bool GetRH(string prompt)
        {
            string[] valid = { "R", "r", "H", "h" };
            string ans;
            
            ans = GetString(prompt, valid, "Please enter h or r only!");
            return (ans == "R" || ans == "r");
        }
        static bool GetYesNo(string prompt)
        {
            string[] valid = { "YES", "Y", "NO", "N" };
            string ans;
            ans = GetString(prompt, valid, "?Invalid response, please reenter");
            return (ans == "YES" || ans == "Y");
        }
    }

    
}


