﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
//I'm Hanjie Deng, and this is my Movie Class, modified from the class example

namespace Movies
{
    class Movie
    {
        public string Name;
        public List<DateTime> Times;
        public string Runtime;
        public string Theater; //String should be okay here, can use int instead but is more work
        public string Rating;
        public Movie()
        {
            Name = "";
            Times = new List<DateTime>();
            Runtime = "0";
            Theater = "1"; //1 is reserved as per the sheet
            Rating = "";
        }
    }
}