﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Market_Place
{
    class Store
    {
        private string name;
        private int numItems;
        private List<Items> items;

        public string Name { get { return name; } set { name = value; } }
        public int NumItems { get { return numItems; } set { numItems = value; } }

        public Items GetItem(int i) { return items[i]; }

        public Store()
        {
            Name = "";
            NumItems = 0;
            items = null;
        }

        public Store(string nm, int num, List<Items> i)
        {
            Name = nm;
            NumItems = num;
            items = i;
        }
    }
}
