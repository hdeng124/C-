﻿namespace Problem_2__Colors_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CloseButton = new System.Windows.Forms.Button();
            this.Method = new System.Windows.Forms.GroupBox();
            this.Subtractive = new System.Windows.Forms.RadioButton();
            this.Additive = new System.Windows.Forms.RadioButton();
            this.ColorBox = new System.Windows.Forms.GroupBox();
            this.cB3 = new System.Windows.Forms.CheckBox();
            this.cB2 = new System.Windows.Forms.CheckBox();
            this.cB1 = new System.Windows.Forms.CheckBox();
            this.DisplayBox = new System.Windows.Forms.TextBox();
            this.Method.SuspendLayout();
            this.ColorBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // CloseButton
            // 
            this.CloseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CloseButton.Location = new System.Drawing.Point(439, 49);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(103, 60);
            this.CloseButton.TabIndex = 0;
            this.CloseButton.Text = "Close";
            this.CloseButton.UseVisualStyleBackColor = true;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // Method
            // 
            this.Method.Controls.Add(this.Subtractive);
            this.Method.Controls.Add(this.Additive);
            this.Method.Location = new System.Drawing.Point(62, 63);
            this.Method.Name = "Method";
            this.Method.Size = new System.Drawing.Size(129, 76);
            this.Method.TabIndex = 9;
            this.Method.TabStop = false;
            this.Method.Text = "Method";
            // 
            // Subtractive
            // 
            this.Subtractive.AutoSize = true;
            this.Subtractive.BackColor = System.Drawing.SystemColors.Control;
            this.Subtractive.ForeColor = System.Drawing.Color.Black;
            this.Subtractive.Location = new System.Drawing.Point(24, 42);
            this.Subtractive.Name = "Subtractive";
            this.Subtractive.Size = new System.Drawing.Size(79, 17);
            this.Subtractive.TabIndex = 1;
            this.Subtractive.TabStop = true;
            this.Subtractive.Text = "Subtractive";
            this.Subtractive.UseVisualStyleBackColor = false;
            this.Subtractive.CheckedChanged += new System.EventHandler(this.Subtractive_CheckedChanged);
            // 
            // Additive
            // 
            this.Additive.AutoSize = true;
            this.Additive.Location = new System.Drawing.Point(25, 19);
            this.Additive.Name = "Additive";
            this.Additive.Size = new System.Drawing.Size(63, 17);
            this.Additive.TabIndex = 0;
            this.Additive.TabStop = true;
            this.Additive.Text = "Additive";
            this.Additive.UseVisualStyleBackColor = true;
            this.Additive.CheckedChanged += new System.EventHandler(this.Additive_CheckedChanged);
            // 
            // ColorBox
            // 
            this.ColorBox.Controls.Add(this.cB3);
            this.ColorBox.Controls.Add(this.cB2);
            this.ColorBox.Controls.Add(this.cB1);
            this.ColorBox.Location = new System.Drawing.Point(231, 63);
            this.ColorBox.Name = "ColorBox";
            this.ColorBox.Size = new System.Drawing.Size(115, 126);
            this.ColorBox.TabIndex = 10;
            this.ColorBox.TabStop = false;
            this.ColorBox.Text = "Additive";
            // 
            // cB3
            // 
            this.cB3.AutoSize = true;
            this.cB3.Location = new System.Drawing.Point(18, 75);
            this.cB3.Name = "cB3";
            this.cB3.Size = new System.Drawing.Size(47, 17);
            this.cB3.TabIndex = 2;
            this.cB3.Text = "Blue";
            this.cB3.UseVisualStyleBackColor = true;
            this.cB3.CheckedChanged += new System.EventHandler(this.cB3_CheckedChanged);
            // 
            // cB2
            // 
            this.cB2.AutoSize = true;
            this.cB2.Location = new System.Drawing.Point(18, 52);
            this.cB2.Name = "cB2";
            this.cB2.Size = new System.Drawing.Size(55, 17);
            this.cB2.TabIndex = 1;
            this.cB2.Text = "Green";
            this.cB2.UseVisualStyleBackColor = true;
            this.cB2.CheckedChanged += new System.EventHandler(this.cB2_CheckedChanged);
            // 
            // cB1
            // 
            this.cB1.AutoSize = true;
            this.cB1.Location = new System.Drawing.Point(18, 29);
            this.cB1.Name = "cB1";
            this.cB1.Size = new System.Drawing.Size(46, 17);
            this.cB1.TabIndex = 0;
            this.cB1.Text = "Red";
            this.cB1.UseVisualStyleBackColor = true;
            this.cB1.CheckedChanged += new System.EventHandler(this.cB1_CheckedChanged);
            // 
            // DisplayBox
            // 
            this.DisplayBox.BackColor = System.Drawing.SystemColors.Window;
            this.DisplayBox.Location = new System.Drawing.Point(35, 244);
            this.DisplayBox.Multiline = true;
            this.DisplayBox.Name = "DisplayBox";
            this.DisplayBox.Size = new System.Drawing.Size(507, 188);
            this.DisplayBox.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 462);
            this.Controls.Add(this.DisplayBox);
            this.Controls.Add(this.ColorBox);
            this.Controls.Add(this.Method);
            this.Controls.Add(this.CloseButton);
            this.Name = "Form1";
            this.Text = "Colors";
            this.Method.ResumeLayout(false);
            this.Method.PerformLayout();
            this.ColorBox.ResumeLayout(false);
            this.ColorBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.GroupBox Method;
        private System.Windows.Forms.RadioButton Subtractive;
        private System.Windows.Forms.RadioButton Additive;
        private System.Windows.Forms.GroupBox ColorBox;
        private System.Windows.Forms.CheckBox cB3;
        private System.Windows.Forms.CheckBox cB2;
        private System.Windows.Forms.CheckBox cB1;
        private System.Windows.Forms.TextBox DisplayBox;
    }
}

