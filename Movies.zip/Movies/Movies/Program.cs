﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
//I'm Hanjie Deng, and this is my Program

namespace Movies
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Movie> movies = new List<Movie>();
            string[] tokens;
            string detailLine;
            try
            {
                //StreamReader takes in the file of movies.
                using (StreamReader sr = new StreamReader("movies.txt"))
                //This whole thing just initializes the movies into the program
                {
                    while (sr.Peek() >= 0)
                    {
                        detailLine = sr.ReadLine();
                        tokens = detailLine.Split(',');
                        Movie tmpMovie = new Movie();
                        List<int> tmpInt = new List<int>();
                        tmpMovie.Theater = tokens[0]; //If int is used instead, must use Convert.ToInt32(), which is probably okay
                        tmpMovie.Name = tokens[1].Trim();
                        tmpMovie.Rating = tokens[2].Trim();
                        tmpMovie.Runtime = tokens[3].Trim();
                        for (int i = 4; i < tokens.Count(); i++)
                            tmpMovie.Times.Add(Convert.ToDateTime(tokens[i]));
                        movies.Add(tmpMovie);
                    }
                }
            }
            catch
            {
                Console.WriteLine("Error in File.");
                Environment.Exit(0);
            }
            while (true) //And the rest of the program, this is where the movies are displayed and the user inputs commands
            {
                //The primary routine for the program, this is all basic printing parts:
                /*
                 foreach (Movie m in movies)
                            {
                                Console.WriteLine("\nTheater {0}: ", m.Theater); //Theater
                                Console.WriteLine("{0} ", m.Name); //Title
                                Console.WriteLine("{0}", m.Rating); //MPAA
                                Console.WriteLine("{0}", m.Runtime); //Runtime
                                foreach (DateTime x in m.Times) //Find all Times
                                    Console.WriteLine("{0}", x.ToString("HH:mm")); //Print Them in 24h format as specified
                            } 
                 */
                string[] commands = {"A", "M", "T", "F", "X"}; //These are all the valid commands
                string command = GetString("Enter a Command A/M/T/F/X: ", commands, "?Invalid response, please reenter");
                switch (command)
                {
                    case ("X"): //Exit
                        {
                            Environment.Exit(0);
                            break;
                        }
                        
                    case("A"): //"Print a list of all movies and corresponding theater numbers"
                        {
                            Console.WriteLine("Here are today's movie listings and theater numbers:");
                            foreach (Movie m in movies)
                            {
                                Console.WriteLine("\nTheater {0}: ", m.Theater); //Theater
                                Console.WriteLine("{0} ", m.Name); //Title
                            }
                            break;
                        }
                    case ("M"): //"Print information about a specific movie (Theatre number, title, and rating)"
                        {
                        prompt:Console.WriteLine("Enter a Theater Number: ");
                            int theater;
                            bool isvalid = int.TryParse(Console.ReadLine(), out  theater);
                            while(!isvalid) //Check validity
                            {
                                Console.Write("Invalid Response: Not an Integer. ");
                                goto prompt;
                            }
                            bool match = false;
                            foreach (Movie m in movies) //Instantiate new loop to check theater #
                            {
                                if (theater.ToString() == m.Theater) //Check each movie's theater # for a match
                                {
                                    Console.WriteLine("\nTheater {0}: ", m.Theater); //Theater
                                    Console.WriteLine("{0} ", m.Name); //Title
                                    Console.WriteLine("{0}", m.Rating); //MPAA
                                    match = true;
                                }
                            }
                            if (match == false)
                                Console.WriteLine("No Movies Found.");
                            break;
                        }
                    case("T"): //"Print inormation about a specific movie (name, times for each showing)
                        {
                            bool match = false;
                        prompt: Console.WriteLine("Enter a Theater Number: ");
                            int theater;
                            bool isvalid = int.TryParse(Console.ReadLine(), out  theater);
                            while (!isvalid) //Check validity
                            {
                                Console.Write("Invalid Response: Not an Integer. ");
                                goto prompt;
                            }
                            foreach (Movie m in movies) //Instantiate new loop to check theater #
                            {
                                if (theater.ToString() == m.Theater) //Check each movie's theater # for a match
                                {
                                    Console.WriteLine("\nTheater {0}: ", m.Theater); //Theater
                                    Console.WriteLine("{0} ", m.Name); //Title
                                    foreach (DateTime x in m.Times) //Find all Times
                                        Console.WriteLine("{0}", x.ToString("HH:mm")); //Print Them in 24h format as specified
                                }
                            }
                            if (match == false)
                                Console.WriteLine("No Movies Found.");
                            break;
                        }
                    case("F"): //"Find all movies that begin within a specified time frame. Print all movies that match
                            {
                       timeprompt: Console.WriteLine("Enter a Time: "); //Prompt initial time
                            DateTime time;
                            bool isvalid = DateTime.TryParse(Console.ReadLine(), out  time);
                            while (!isvalid) //Check validity
                            {
                                Console.Write("Invalid Response: Not a DateTime. ");
                                goto timeprompt;
                            }
                            int frame;
                        frameprompt: Console.WriteLine("Enter a Timeframe in Minutes: "); //Prompt interval
                            isvalid = int.TryParse(Console.ReadLine(), out  frame);
                            while (!isvalid) //Check validity
                            {
                                Console.Write("Invalid Response: Not an Integer. ");
                                goto frameprompt;
                            }
                                //Instantiate the timeframe
                            DateTime earliest = time.AddMinutes(frame * -1);
                            DateTime latest = time.AddMinutes(frame);
                            Console.WriteLine("Timeframe selected: {0} - {1}", earliest.ToString("HH:mm"), latest.ToString("HH:mm"));
                            bool match = false; 
                            foreach (Movie m in movies) //Instantiate new loop to check theater #
                            {
                                int edifference, ldifference;
                                for(int i = 0; i < m.Times.Count(); i++)
                                {
                                edifference = Convert.ToInt32(m.Times[i].ToString("HHmm")) - Convert.ToInt32(earliest.ToString("HHmm"));
                                ldifference = Convert.ToInt32(latest.ToString("HHmm")) - Convert.ToInt32(m.Times[i].ToString("HHmm"));
                                if(edifference >= 0 && ldifference >= 0) //Check to see if it's within the timeframe
                                {
                                    Console.WriteLine("\nTheater {0}: ", m.Theater); //Theater
                                    Console.WriteLine("{0} ", m.Name); //Title
                                    foreach (DateTime x in m.Times) //Find all Times
                                        Console.WriteLine("{0}", x.ToString("HH:mm")); //Print Them in 24h format as specified
                                        match = true;
                                }
                             }
                                
                            }
                            if (match == false)
                                Console.WriteLine("No Movies Found.");
                            break;
                            }
                    default: //If error check fails
                        {
                            Console.WriteLine("Error, invalid command passed through error checking\n");
                            Environment.Exit(1);
                            break;
                        }
                }
            }
        }
        static bool GetYesNo(string prompt)
        {
            string[] valid = { "YES", "Y", "NO", "N" };
            string ans;
            ans = GetString(prompt, valid, "?Invalid response, please reenter");
            return (ans == "YES" || ans == "Y");
        }
        static string GetString(string prompt, string[] valid, string error)
        {
            //Prompt = user prompt, Valid = array of valid repsonses , error = msg to display on invalid entry
            //ALL STRINGS RETURNED UPPER CASE. ALL VALID[] ENTRIES MUST BE IN UPPER CASE
            string response;
            bool OK = false;
            do
            {
                Console.Write(prompt);
                response = Console.ReadLine().ToUpper();
                foreach (string s in valid) if (response == s.ToUpper()) OK = true;
                if (!OK) Console.WriteLine(error);
            }
            while (!OK);
            return response;
        }
    }
}
