﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECE264Lab2
{
    class Program
    {
        static void Main(string[] args)
        {

            DateTime bd;
            DateTime td;
            DateTime wd;
            string a;
            string[] validan = { "Y", "N", "YES", "NO", "YE" };
            string name;
            td = DateTime.Today;
            Again:
            if (GetYesNo("Use special date for today? <Y or N>:")) //ask if user want to use special date
            {
                Console.WriteLine("Enter special date for 'today'");
                a = Console.ReadLine();
                bool c = DateTime.TryParse(a, out wd);
                while (!c)
                {
                    Console.WriteLine("Please enter a valid date:");
                    a = Console.ReadLine();
                    c = DateTime.TryParse(a, out wd);
                }
            }
            else
            {
                wd = td;
            }
            while (GetYesNo("Would you like to get your Astrological pesonality traits? "))
            {

                Console.WriteLine("Enter name: ");
                name = Console.ReadLine();
                Console.Write("Enter birthdate: ");
                a = Console.ReadLine();
                bool b = DateTime.TryParse(a, out bd);
                while (!b)
                {
                    Console.WriteLine("Please enter a valid date:");
                    a = Console.ReadLine();
                    b = DateTime.TryParse(a, out bd);
                }

                Console.WriteLine("Thank you, {0}. Based on the information provided, I can tell you the following: ", name);


                int ny = 0, nm = 0, nd = 0;
                //wd = bd;
                DateTime dt = bd;
                while (dt.AddYears(1) <= wd)
                {
                    dt = dt.AddYears(1);
                    ny++;
                }
                while (dt.AddMonths(1) <= wd)
                {
                    dt = dt.AddMonths(1);
                    nm++;
                }
                while (dt.AddDays(1) <= wd)
                {
                    dt = dt.AddDays(1);
                    nd++;
                }
                Console.WriteLine("   You are {0} years, {1} months, and {2} days old", ny, nm, nd);

                /*int day = 0;
                int month = 0;
                month = 12 - nm;
                day = (month * 30)-nd;*/


                int numdays;
                DateTime now = bd.AddYears(wd.Year-bd.Year);
                if (now < wd)
                    now = now.AddYears(1);
                numdays = (now-wd).Days;
                /*int days = 0;
                days = GetDaysUntilBirthday(dt);*/

                Console.WriteLine("   There are {0} days until your next birthday", numdays);



                switch (bd.Month)
                {
                    case 1:
                        if (bd.Day <= 20)
                        {
                            Console.Write("   You were born under the sign of Capricorn\n   You have the following Personality Traits:\n");
                            Console.Write("\tPractical and prudent\n" +
                                        "\tAmbitious and disciplined\n" +
                                        "\tPatient and careful\n" +
                                        "\tHumorous and reserved\n\n" +
                                        "\tPessimistic and fatalistic\n" +
                                        "\tMiserly and grudging\n");
                        }
                        else
                        {
                            Console.Write("   You were born under the sign of Aquarius\n   You have the following Personality Traits:\n");
                            Console.Write("\tFriendly and humanitarian\n" +
                                            "\tHonest and loyal\n" +
                                            "\tOriginal and inventive\n" +
                                            "\tIndependent and intellectual\n\n" +
                                            "\tIntractable and contrary\n" +
                                            "\tPerverse and unpredictable\n" +
                                            "\tUnemotional and detached\n");
                        } break;

                    case 2:
                        if (bd.Day <= 19)
                        {
                            Console.Write("   You were born under the sign of Aquarius\n   You have the following Personality Traits:\n");
                            Console.Write("\tFriendly and humanitarian\n" +
                                            "\tHonest and loyal\n" +
                                            "\tOriginal and inventive\n" +
                                            "\tIndependent and intellectual\n\n" +
                                            "\tIntractable and contrary\n" +
                                            "\tPerverse and unpredictable\n" +
                                            "\tUnemotional and detached\n");
                        }
                        else
                        {
                            Console.Write("   You were born under the sign of Pisces\n   You have the following Personality Traits:\n");
                            Console.Write("\tFriendly and humanitarian\n" +
                                            "\tImaginative and sensitive\n" +
                                            "\tCompassionate and kind\n" +
                                            "\tSelfless and unworldly\n" +
                                            "\tIntuitive and sympathetic\n\n" +
                                            "\tEscapist and idealistic\n" +
                                            "\tSecretive and vague\n" +
                                            "\tWeak-willed and easily led\n");

                        } break;

                    case 3:
                        if (bd.Day <= 20)
                        {
                            Console.Write("   You were born under the sign of Pisces\n   You have the following Personality Traits:\n");
                            Console.Write("\tFriendly and humanitarian\n" +
                                            "\tImaginative and sensitive\n" +
                                            "\tCompassionate and kind\n" +
                                            "\tSelfless and unworldly\n" +
                                            "\tIntuitive and sympathetic\n\n" +
                                            "\tEscapist and idealistic\n" +
                                            "\tSecretive and vague\n" +
                                            "\tWeak-willed and easily led\n");
                        }
                        else
                        {
                            Console.Write("   You were born under the sign of Aries\n   You have the following Personality Traits:\n");
                            Console.Write("\tAventurous and energetic\n" +
                                            "\tPioneering and courageous\n" +
                                            "\tEnthusiastic and confident\n" +
                                            "\tDynamic and quick-witted\n\n" +
                                            "\tSelfish and quick-tempered\n" +
                                            "\tImpulsive and impatient\n" +
                                            "\tFoolhardy and daredevil\n");

                        } break;

                    case 4:
                        if (bd.Day <= 20)
                        {
                            Console.Write("   You were born under the sign of Aries\n   You have the following Personality Traits:\n");
                            Console.Write("\tAventurous and energetic\n" +
                                            "\tPioneering and courageous\n" +
                                            "\tEnthusiastic and confident\n" +
                                            "\tDynamic and quick-witted\n\n" +
                                            "\tSelfish and quick-tempered\n" +
                                            "\tImpulsive and impatient\n" +
                                            "\tFoolhardy and daredevil\n");
                        }
                        else
                        {
                            Console.Write("   You were born under the sign of Taurus\n   You have the following Personality Traits:\n");
                            Console.Write("\tPatient and reliable\n" +
                                            "\tWarmhearted and loving\n" +
                                            "\tPersistent and determined\n" +
                                            "\tPlacid and security loving\n\n" +
                                            "\tJealous and possessive\n" +
                                            "\tResentful and inflexible\n" +
                                            "\tSelf-indulgent and greedy\n");

                        } break;

                    case 5:
                        if (bd.Day <= 21)
                        {
                            Console.Write("   You were born under the sign of Taurus\n   You have the following Personality Traits:\n");
                            Console.Write("\tPatient and reliable\n" +
                                            "\tWarmhearted and loving\n" +
                                            "\tPersistent and determined\n" +
                                            "\tPlacid and security loving\n\n" +
                                            "\tJealous and possessive\n" +
                                            "\tResentful and inflexible\n" +
                                            "\tSelf-indulgent and greedy\n");
                        }
                        else
                        {
                            Console.Write("   You were born under the sign of Gemini\n   You have the following Personality Traits:\n");
                            Console.Write("\tAdaptable and versatile\n" +
                                            "\tCommunicative and witty\n" +
                                            "\tIntellectual and eloquent\n" +
                                            "\tYouthful and lively\n\n" +
                                            "\tNervous and tense\n" +
                                            "\tSuperficial and inconsistent\n" +
                                            "\tCunning and inquisitive\n");

                        } break;

                    case 6:
                        if (bd.Day <= 21)
                        {
                            Console.Write("   You were born under the sign of Gemini\n   You have the following Personality Traits:\n");
                            Console.Write("\tAdaptable and versatile\n" +
                                            "\tCommunicative and witty\n" +
                                            "\tIntellectual and eloquent\n" +
                                            "\tYouthful and lively\n\n" +
                                            "\tNervous and tense\n" +
                                            "\tSuperficial and inconsistent\n" +
                                            "\tCunning and inquisitive\n");

                        }
                        else
                        {
                            Console.Write("   You were born under the sign of Cancer\n   You have the following Personality Traits:\n");
                            Console.Write("\tEmotional and loving\n" +
                                            "\tIntuitive and imaginative\n" +
                                            "\tShrewd and cautious\n" +
                                            "\tProtective and sympathetic\n\n" +
                                            "\tChangeable and moody\n" +
                                            "\tOveremotional and touchy\n" +
                                            "\tClinging and unable to let go\n");

                        } break;

                    case 7:
                        if (bd.Day <= 22)
                        {
                            Console.Write("   You were born under the sign of Cancer\n   You have the following Personality Traits:\n");
                            Console.Write("\tEmotional and loving\n" +
                                            "\tIntuitive and imaginative\n" +
                                            "\tShrewd and cautious\n" +
                                            "\tProtective and sympathetic\n\n" +
                                            "\tChangeable and moody\n" +
                                            "\tOveremotional and touchy\n" +
                                            "\tClinging and unable to let go\n");
                        }
                        else
                        {
                            Console.Write("   You were born under the sign of Leo\n   You have the following Personality Traits:\n");
                            Console.Write("\tGenerous and warmhearted\n" +
                                            "\tCreative and enthusiastic\n" +
                                            "\tBroad-minded and expansive\n" +
                                            "\tFaithful and loving\n\n" +
                                            "\tPompous and patronizing\n" +
                                            "\tBossy and interfering\n" +
                                            "\tDogmatic and intolerant\n");

                        } break;

                    case 8:
                        if (bd.Day <= 21)
                        {
                            Console.Write("   You were born under the sign of Leo\n   You have the following Personality Traits:\n");
                            Console.Write("\tGenerous and warmhearted\n" +
                                            "\tCreative and enthusiastic\n" +
                                            "\tBroad-minded and expansive\n" +
                                            "\tFaithful and loving\n\n" +
                                            "\tPompous and patronizing\n" +
                                            "\tBossy and interfering\n" +
                                            "\tDogmatic and intolerant\n");
                        }
                        else
                        {
                            Console.Write("   You were born under the sign of Virgo\n   You have the following Personality Traits:\n");
                            Console.Write("\tModest and shy\n" +
                                            "\tMeticulous and reliable\n" +
                                            "\tPractical and diligent\n" +
                                            "\tIntelligent and analytical\n\n" +
                                            "\tFussy and a worrier\n" +
                                            "\tOvercritical and harsh\n" +
                                            "\tPerfectionist and conservative\n");

                        } break;

                    case 9:
                        if (bd.Day <= 23)
                        {
                            Console.Write("   You were born under the sign of Virgo\n   You have the following Personality Traits:\n");
                            Console.Write("\tModest and shy\n" +
                                            "\tMeticulous and reliable\n" +
                                            "\tPractical and diligent\n" +
                                            "\tIntelligent and analytical\n\n" +
                                            "\tFussy and a worrier\n" +
                                            "\tOvercritical and harsh\n" +
                                            "\tPerfectionist and conservative\n");
                        }
                        else
                        {
                            Console.Write("   You were born under the sign of Libra\n   You have the following Personality Traits:\n");
                            Console.Write("\tDiplomatic and urbane\n" +
                                            "\tRomantic and charming\n" +
                                            "\tEasygoing and sociable\n" +
                                            "\tIdealistic and peaceable\n\n" +
                                            "\tIndecisive and changeable\n" +
                                            "\tGullible and easily influenced\n" +
                                            "\tFlirtatious and self-indulgent\n");

                        } break;

                    case 10:
                        if (bd.Day <= 23)
                        {
                            Console.Write("   You were born under the sign of Libra\n   You have the following Personality Traits:\n");
                            Console.Write("\tDiplomatic and urbane\n" +
                                            "\tRomantic and charming\n" +
                                            "\tEasygoing and sociable\n" +
                                            "\tIdealistic and peaceable\n\n" +
                                            "\tIndecisive and changeable\n" +
                                            "\tGullible and easily influenced\n" +
                                            "\tFlirtatious and self-indulgent\n");
                        }
                        else
                        {
                            Console.Write("   You were born under the sign of Scorpio\n   You have the following Personality Traits:\n");
                            Console.Write("\tDetermined and forceful\n" +
                                            "\tEmotional and intuitive\n" +
                                            "\tPowerful and passionate\n" +
                                            "\tExciting and magnetic\n\n" +
                                            "\tJealous and resentful\n" +
                                            "\tCompulsive and obsessive\n" +
                                            "\tSecretive and obstinate\n");

                        } break;

                    case 11:
                        if (bd.Day <= 22)
                        {
                            Console.Write("   You were born under the sign of Scorpio\n   You have the following Personality Traits:\n");
                            Console.Write("\tDetermined and forceful\n" +
                                            "\tEmotional and intuitive\n" +
                                            "\tPowerful and passionate\n" +
                                            "\tExciting and magnetic\n\n" +
                                            "\tJealous and resentful\n" +
                                            "\tCompulsive and obsessive\n" +
                                            "\tSecretive and obstinate\n");
                        }
                        else
                        {
                            Console.Write("   You were born under the sign of Sagittarious\n   You have the following Personality Traits:\n");
                            Console.Write("\tOptimistic and freedom-loving\n" +
                                            "\tJovial and good-humored\n" +
                                            "\tHonest and straightforward\n" +
                                            "\tIntellectual and philosophical\n\n" +
                                            "\tBlindly optimistic and careless\n" +
                                            "\tIrresponsible and superficial\n" +
                                            "\tTactless and restless\n");

                        } break;

                    case 12:
                        if (bd.Day <= 22)
                        {
                            Console.Write("   You were born under the sign of Sagittarious\n   You have the following Personality Traits:\n");
                            Console.Write("\tOptimistic and freedom-loving\n" +
                                            "\tJovial and good-humored\n" +
                                            "\tHonest and straightforward\n" +
                                            "\tIntellectual and philosophical\n\n" +
                                            "\tBlindly optimistic and careless\n" +
                                            "\tIrresponsible and superficial\n" +
                                            "\tTactless and restless\n");
                        }
                        else
                        {
                            Console.Write("   You were born under the sign of Capricorn\n   You have the following Personality Traits:\n");
                            Console.Write("\tPractical and prudent\n" +
                                        "\tAmbitious and disciplined\n" +
                                        "\tPatient and careful\n" +
                                        "\tHumorous and reserved\n\n" +
                                        "\tPessimistic and fatalistic\n" +
                                        "\tMiserly and grudging\n");

                        } break;

                    default:
                        Console.Write("Error");
                        break;
                }

                goto Again;
            }

        }


        static string GetString(string anything, string[] valid, string error)
        {
            // prompt=user prompt, valid=array of valid responses, error=msg to display on invalid entry
            // ALL STRINGS RETURNED UPPER CASE. ALL valid[] ENTRIES MUST BE IN UPPER CASE
            string response;
            bool OK = false;
            do
            {
                Console.Write(anything);
                response = Console.ReadLine().ToUpper();
                foreach (string s in valid) if (response == s.ToUpper()) OK = true;
                if (!OK) Console.WriteLine(error);
            } while (!OK);
            return response;
        }

        static bool GetYesNo(string prompt)
        {
            string[] valid = { "YES", "Y", "NO", "N", "YE", "OK" };
            string ans;
            ans = GetString(prompt, valid, "?Invalid response, please reenter");
            return (ans == "YES" || ans == "Y" || ans == "YE" || ans == "OK");
        }

        private static int GetDaysUntilBirthday(DateTime bd)
        {
            var nextBirthday = bd.AddYears(DateTime.Today.Year - bd.Year);
            if (nextBirthday < DateTime.Today)
            {
                nextBirthday = nextBirthday.AddYears(1);
            }
            return (nextBirthday - DateTime.Today).Days;



        }
    }
}
                        

    
        
