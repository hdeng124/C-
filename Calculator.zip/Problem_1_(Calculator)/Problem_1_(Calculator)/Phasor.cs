﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1__Calculator_
{
    class Phasor
    {
        private double magnitude;
        private double angle;

        public double Magnitude { get { return magnitude; } set { magnitude = value; } }
        public double Angle { get { return angle; } set { angle = value; } }
        public Phasor()
        {
            Magnitude = 0.0; Angle = 0.0;
        }

        public Phasor(double m, double a)
        {
            Magnitude = m; Angle = a;
        }

        public static bool TryParse(string s, out Phasor ph)   //Seperates a Phasor using IndexOf
        {
            int pat = s.IndexOf("@");
            if (pat >= 0)
            {
                string sMagnitude = s.Substring(0, pat);
                string sAngle = s.Substring(pat + 1);
                bool bm, ba;                //True or false values, to determing authenticity of inputted values
                double dMagniude, dAngle;
                bm = Double.TryParse(sMagnitude, out dMagniude);
                ba = Double.TryParse(sAngle, out dAngle);

                ph = new Phasor(dMagniude, dAngle);
                return bm && ba;
            }
            else
            {
                ph = new Phasor();
                return false;
            }
        }

        public override string ToString()   //Returns two values (Magnitude and Angle) in Phasor notation (Magnitude@Angle)
        {
            return Magnitude.ToString() + "@" + Angle.ToString();
        }
        public static Phasor operator +(Phasor a, Phasor b)
        {
            Phasor c = new Phasor();
            // do math - separate "magnitude and angle parts of a and b (a.Magnitude, etc)

            return c;

        }
        /*
        // Checks for a double
        public static double GetDouble(string prompt, string error)
        {
            double result;
            string userInput;
            bool OK = false; //assume bad data
            do
            {
                Console.Write(prompt);
                userInput = Console.ReadLine();
                OK = double.TryParse(userInput, out result);
                if (!OK) Console.WriteLine(error);
            } while (!OK);
            return result;
        }
        //Checks for a phasor
        public static Phasor GetPhasor(string prompt, string error)
        {
            Phasor result;
            string userInput;
            bool OK = false;
            do
            {
                Console.Write(prompt);
                userInput = Console.ReadLine();
                OK = Phasor.TryParse(userInput, out result);
                if (!OK) Console.WriteLine(error);
            } while (!OK);
            return result;
        }
         */
    }
}
